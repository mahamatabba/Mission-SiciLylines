<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Client;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ResetType;

use Symfony\Component\HttpFoundation\Request;


class InscriptionController extends AbstractController
{
    /**
     * @Route("/inscription", name="inscription")
     */
    public function index(Request $request): Response
    {
        $client=new Client();
        $form = $this->createFormBuilder($client)
                    ->add('nom', TextType::class)
                    ->add('adresse', TextType::class)
                    ->add('cp', TextType::class)
                    ->add('ville', TextType::class)
                    ->add('login', TextType::class,['mapped'=>false])
                    ->add('motDePasse', PasswordType::class,['mapped'=>false])
                    ->add('Valider',SubmitType::class)
                    ->add('annuler',ResetType::class)
                    ->getForm();

            $form->handleRequest($request) ;

            if ($form->isSubmitted() ) {	
                

                $em= $this->getDoctrine()->getManager();
                $em->persist($client);
                $em->flush();
             }

        return $this->render('inscription/index.html.twig', [
            'form' =>$form->createView()
        ]);
    }
}
