<?php

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ResetType;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Port;
use App\Entity\Traversee;
use Doctrine\Persistence\ManagerRegistry;
use App\Repository\TraverseeRepository;
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\Form\Forms;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Doctrine\ORM\EntityRepository;
use App\Entity\bateau;
use Open\OpcBundle\Entity\Liaison;



class RechercherController extends AbstractController
{
    /**
     * @Route("/rechercher", name="rechercher")
     */
    public function index(TraverseeRepository $traversees): Response

    {
        
            
        $traversees= $this->getDoctrine()
        ->getRepository(traversee::Class)
        ->findAll();

         

        

        return $this->render('rechercher/index.html.twig', [
            'traversees' =>$traversees
        ]);
    }
}
