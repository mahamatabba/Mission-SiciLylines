<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* rechercher/index.html.twig */
class __TwigTemplate_f8ec50f53d9000c50cd587b62301c657371dc202d9ea89ae50679910bae77d15 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "rechercher/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "rechercher/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello RechercherController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
";
        // line 7
        $this->loadTemplate("/nav1.html.twig", "rechercher/index.html.twig", 7)->display($context);
        // line 8
        echo "
<br>
<br>
<center>

<br>
<p> Réserve une traversee </p>
<br>
</center>
<div class=\"container\">

<table class=\"table table-dark table-striped\">
  <thead>
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Durée</th>         
      <th scope=\"col\">Port de Départ</th> 
      <th scope=\"col\">Port d' Arrivée</th>  
      <th scope=\"col\">Date</th> 
      <th scope=\"col\">#</th> 
      
    </tr>
  </thead>
  <tbody>
    ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["traversees"]) || array_key_exists("traversees", $context) ? $context["traversees"] : (function () { throw new RuntimeError('Variable "traversees" does not exist.', 32, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["traversee"]) {
            // line 33
            echo "           <tr>
       
           <td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["traversee"], "id", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
           <td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "laLiaison", [], "any", false, false, false, 36), "duree", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
           <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "laLiaison", [], "any", false, false, false, 37), "portDepart", [], "any", false, false, false, 37), "nom", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
           <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "laLiaison", [], "any", false, false, false, 38), "portArrivee", [], "any", false, false, false, 38), "nom", [], "any", false, false, false, 38), "html", null, true);
            echo "</td>
           <td>";
            // line 39
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["traversee"], "date", [], "any", false, false, false, 39), "y-m-d"), "html", null, true);
            echo "</td>
         <td><button type=\"button\" class=\"btn btn-primary\">Réserver</button></td>
           

           </tr>

            
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['traversee'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo " 
    

  </tbody>
</table>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "rechercher/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 46,  128 => 39,  124 => 38,  120 => 37,  116 => 36,  112 => 35,  108 => 33,  104 => 32,  78 => 8,  76 => 7,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello RechercherController!{% endblock %}

{% block body %}

{% include '/nav1.html.twig'  %}

<br>
<br>
<center>

<br>
<p> Réserve une traversee </p>
<br>
</center>
<div class=\"container\">

<table class=\"table table-dark table-striped\">
  <thead>
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Durée</th>         
      <th scope=\"col\">Port de Départ</th> 
      <th scope=\"col\">Port d' Arrivée</th>  
      <th scope=\"col\">Date</th> 
      <th scope=\"col\">#</th> 
      
    </tr>
  </thead>
  <tbody>
    {% for traversee in traversees %}
           <tr>
       
           <td>{{traversee.id}}</td>
           <td>{{traversee.laLiaison.duree}}</td>
           <td>{{traversee.laLiaison.portDepart.nom}}</td>
           <td>{{traversee.laLiaison.portArrivee.nom}}</td>
           <td>{{traversee.date | date('y-m-d')}}</td>
         <td><button type=\"button\" class=\"btn btn-primary\">Réserver</button></td>
           

           </tr>

            
    {% endfor %} 
    

  </tbody>
</table>
</div>
{% endblock %}
", "rechercher/index.html.twig", "/var/www/html/SicilyLines/templates/rechercher/index.html.twig");
    }
}
