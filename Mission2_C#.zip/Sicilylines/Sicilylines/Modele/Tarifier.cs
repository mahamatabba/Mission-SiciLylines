﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sicilylines.Modele
{
    public class Tarifier
    {
      
        private string tarif;

        
        private int idLiaisons;

      
        public int IdLiaisons { get => idLiaisons; set => idLiaisons = value; }
        public string Tarif { get => tarif; set => tarif = value; }


        public Tarifier( int idLiaisons, string tarif)
        {
            this.IdLiaisons = idLiaisons;
            this.tarif = tarif;

        }

        public  override string ToString()
        {
            return (this.tarif+ " euros ");
        }
    }
}
