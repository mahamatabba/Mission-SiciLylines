﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sicilylines.Modele
{
    public class Tarifier
    {
      
        private string tarif;

        private int idLiaisons;
        private int idTarif;

      
        public int IdTarif { get => idTarif; set => idTarif = value; }
        public string Tarif { get => tarif; set => tarif = value; }
        public int IdLiaisons { get => idLiaisons; set => idLiaisons = value; }

        public Tarifier( int idTarif, string tarif, int idLiaisons)
        {
            this.idTarif = idTarif;
            this.tarif = tarif;
            this.idLiaisons = idLiaisons;

        }

        public  override string ToString()
        {
            return (this.tarif);
        }
    }
}
