-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 13 Avril 2022 à 16:53
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `sicilyline`
--

-- --------------------------------------------------------

--
-- Structure de la table `bateau`
--

CREATE TABLE IF NOT EXISTS `bateau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longueur` double NOT NULL,
  `largeur` double NOT NULL,
  `vitesse` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `bateau`
--

INSERT INTO `bateau` (`id`, `nom`, `longueur`, `largeur`, `vitesse`) VALUES
(1, 'Eduardo', 37.2, 8.6, 26),
(2, 'Platone', 25, 7, 16);

-- --------------------------------------------------------

--
-- Structure de la table `capacite_bateau`
--

CREATE TABLE IF NOT EXISTS `capacite_bateau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie_id` int(11) NOT NULL,
  `capacite_max` int(11) NOT NULL,
  `bateau_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8FFA75E3BCF5E72D` (`categorie_id`),
  KEY `IDX_8FFA75E3A9706509` (`bateau_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id`, `libelle`) VALUES
(1, 'Passager'),
(2, 'Véh.inf.2m'),
(3, 'Véh.sup.2m');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cp` int(11) NOT NULL,
  `ville` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `doctrine_migration_versions`
--

CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20220330213237', '2022-03-30 23:33:01', 31),
('DoctrineMigrations\\Version20220330213813', '2022-03-30 23:38:29', 34),
('DoctrineMigrations\\Version20220330214051', '2022-03-30 23:41:11', 76),
('DoctrineMigrations\\Version20220330214400', '2022-03-30 23:44:12', 36),
('DoctrineMigrations\\Version20220330214550', '2022-03-30 23:46:03', 112),
('DoctrineMigrations\\Version20220330215114', '2022-03-30 23:51:29', 83),
('DoctrineMigrations\\Version20220330215328', '2022-03-30 23:53:43', 51),
('DoctrineMigrations\\Version20220330220834', '2022-03-31 00:08:48', 65),
('DoctrineMigrations\\Version20220330221030', '2022-03-31 00:10:41', 80),
('DoctrineMigrations\\Version20220330221139', '2022-03-31 00:11:53', 89),
('DoctrineMigrations\\Version20220330221228', '2022-03-31 00:12:47', 67),
('DoctrineMigrations\\Version20220330221413', '2022-03-31 00:14:24', 77),
('DoctrineMigrations\\Version20220330223152', '2022-03-31 00:32:25', 131),
('DoctrineMigrations\\Version20220330223727', '2022-03-31 00:37:37', 165),
('DoctrineMigrations\\Version20220330224429', '2022-03-31 00:44:52', 268),
('DoctrineMigrations\\Version20220330224926', '2022-03-31 00:49:39', 285),
('DoctrineMigrations\\Version20220330225522', '2022-03-31 00:55:32', 134),
('DoctrineMigrations\\Version20220330225813', '2022-03-31 00:58:27', 158),
('DoctrineMigrations\\Version20220330230124', '2022-03-31 01:01:41', 174),
('DoctrineMigrations\\Version20220330230645', '2022-03-31 01:06:57', 181),
('DoctrineMigrations\\Version20220330230911', '2022-03-31 01:09:30', 68),
('DoctrineMigrations\\Version20220330231126', '2022-03-31 01:11:37', 80),
('DoctrineMigrations\\Version20220330231741', '2022-03-31 01:17:59', 159),
('DoctrineMigrations\\Version20220330232256', '2022-03-31 01:28:03', 57),
('DoctrineMigrations\\Version20220330233031', '2022-03-31 01:30:42', 239),
('DoctrineMigrations\\Version20220330234207', '2022-03-31 01:42:21', 227);

-- --------------------------------------------------------

--
-- Structure de la table `equipement`
--

CREATE TABLE IF NOT EXISTS `equipement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `equipement`
--

INSERT INTO `equipement` (`id`, `libelle`) VALUES
(1, 'Accès Handicapé'),
(2, 'Bar'),
(3, 'Pont Promenade'),
(4, 'Salon Vidéo');

-- --------------------------------------------------------

--
-- Structure de la table `equipement_propose`
--

CREATE TABLE IF NOT EXISTS `equipement_propose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bateau_id` int(11) DEFAULT NULL,
  `equipement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_367F9AB3A9706509` (`bateau_id`),
  KEY `IDX_367F9AB3806F0F5C` (`equipement_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Contenu de la table `equipement_propose`
--

INSERT INTO `equipement_propose` (`id`, `bateau_id`, `equipement_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 2, 1),
(6, 2, 2);

-- --------------------------------------------------------

--
-- Structure de la table `liaison`
--

CREATE TABLE IF NOT EXISTS `liaison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duree` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `secteur_id` int(11) NOT NULL,
  `port_arrive_id` int(11) NOT NULL,
  `port_depart_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_225AC379F7E4405` (`secteur_id`),
  KEY `IDX_225AC37CEC9B4D0` (`port_arrive_id`),
  KEY `IDX_225AC3794C9CCD3` (`port_depart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=45 ;

--
-- Contenu de la table `liaison`
--

INSERT INTO `liaison` (`id`, `duree`, `secteur_id`, `port_arrive_id`, `port_depart_id`) VALUES
(21, '2', 4, 10, 11),
(34, '6 ', 1, 1, 1),
(35, '4', 2, 1, 3),
(38, '6', 2, 1, 3),
(39, '1', 3, 2, 6),
(40, '1', 4, 2, 6),
(41, '1', 4, 2, 6);

-- --------------------------------------------------------

--
-- Structure de la table `nb_places_reservee`
--

CREATE TABLE IF NOT EXISTS `nb_places_reservee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9ADB8AF3B83297E7` (`reservation_id`),
  KEY `IDX_9ADB8AF3C54C8C93` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `periode`
--

CREATE TABLE IF NOT EXISTS `periode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `periode`
--

INSERT INTO `periode` (`id`, `date_debut`, `date_fin`) VALUES
(1, '2021-09-01', '2022-06-15'),
(2, '2022-06-16', '2022-09-15'),
(3, '2022-09-16', '2023-05-31');

-- --------------------------------------------------------

--
-- Structure de la table `port`
--

CREATE TABLE IF NOT EXISTS `port` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Contenu de la table `port`
--

INSERT INTO `port` (`id`, `nom`) VALUES
(1, 'Palerme'),
(2, 'Ustica'),
(3, 'Lipari'),
(4, 'Messine'),
(5, 'Stromboli'),
(6, 'Vulcano'),
(7, 'Panarea'),
(8, 'Milazzo'),
(9, 'Pantelleria'),
(10, 'Favignana'),
(11, 'Trapani');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `traversee_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_42C8495519EB6921` (`client_id`),
  KEY `IDX_42C84955ED2BB15B` (`traversee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `secteur`
--

CREATE TABLE IF NOT EXISTS `secteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `secteur`
--

INSERT INTO `secteur` (`id`, `libelle`) VALUES
(1, 'Palerme'),
(2, 'Messine'),
(3, 'Milazzo'),
(4, 'Trapani');

-- --------------------------------------------------------

--
-- Structure de la table `tarifer`
--

CREATE TABLE IF NOT EXISTS `tarifer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `liaison_id` int(11) NOT NULL,
  `periode_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `Tarif` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6904C4FFED31185` (`liaison_id`),
  KEY `IDX_6904C4FFF384C1CF` (`periode_id`),
  KEY `IDX_6904C4FFC54C8C93` (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `tarifer`
--

INSERT INTO `tarifer` (`id`, `liaison_id`, `periode_id`, `type_id`, `Tarif`) VALUES
(1, 21, 1, 1, '25'),
(2, 34, 2, 1, '20');

-- --------------------------------------------------------

--
-- Structure de la table `traversee`
--

CREATE TABLE IF NOT EXISTS `traversee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `heure` time NOT NULL,
  `bateau_id` int(11) NOT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B688F501A9706509` (`bateau_id`),
  KEY `IDX_B688F501B83297E7` (`reservation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8CDE5729BCF5E72D` (`categorie_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `type`
--

INSERT INTO `type` (`id`, `libelle`, `categorie_id`) VALUES
(1, 'test', 1);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `capacite_bateau`
--
ALTER TABLE `capacite_bateau`
  ADD CONSTRAINT `FK_8FFA75E3A9706509` FOREIGN KEY (`bateau_id`) REFERENCES `bateau` (`id`),
  ADD CONSTRAINT `FK_8FFA75E3BCF5E72D` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`);

--
-- Contraintes pour la table `equipement_propose`
--
ALTER TABLE `equipement_propose`
  ADD CONSTRAINT `FK_367F9AB3806F0F5C` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`),
  ADD CONSTRAINT `FK_367F9AB3A9706509` FOREIGN KEY (`bateau_id`) REFERENCES `bateau` (`id`);

--
-- Contraintes pour la table `liaison`
--
ALTER TABLE `liaison`
  ADD CONSTRAINT `FK_225AC3794C9CCD3` FOREIGN KEY (`port_depart_id`) REFERENCES `port` (`id`),
  ADD CONSTRAINT `FK_225AC379F7E4405` FOREIGN KEY (`secteur_id`) REFERENCES `secteur` (`id`),
  ADD CONSTRAINT `FK_225AC37CEC9B4D0` FOREIGN KEY (`port_arrive_id`) REFERENCES `port` (`id`);

--
-- Contraintes pour la table `nb_places_reservee`
--
ALTER TABLE `nb_places_reservee`
  ADD CONSTRAINT `FK_9ADB8AF3B83297E7` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`),
  ADD CONSTRAINT `FK_9ADB8AF3C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`);

--
-- Contraintes pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `FK_42C8495519EB6921` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`),
  ADD CONSTRAINT `FK_42C84955ED2BB15B` FOREIGN KEY (`traversee_id`) REFERENCES `traversee` (`id`);

--
-- Contraintes pour la table `tarifer`
--
ALTER TABLE `tarifer`
  ADD CONSTRAINT `FK_6904C4FFC54C8C93` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`),
  ADD CONSTRAINT `FK_6904C4FFED31185` FOREIGN KEY (`liaison_id`) REFERENCES `liaison` (`id`),
  ADD CONSTRAINT `FK_6904C4FFF384C1CF` FOREIGN KEY (`periode_id`) REFERENCES `periode` (`id`);

--
-- Contraintes pour la table `traversee`
--
ALTER TABLE `traversee`
  ADD CONSTRAINT `FK_B688F501A9706509` FOREIGN KEY (`bateau_id`) REFERENCES `bateau` (`id`),
  ADD CONSTRAINT `FK_B688F501B83297E7` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`);

--
-- Contraintes pour la table `type`
--
ALTER TABLE `type`
  ADD CONSTRAINT `FK_8CDE5729BCF5E72D` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
